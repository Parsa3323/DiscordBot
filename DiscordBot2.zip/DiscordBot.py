import discord
from discord.ext import commands
import json
import mysql.connector
from mysql.connector import Error
from datetime import datetime, timedelta

# Load configuration from the JSON file
with open("config.json", mode="r", encoding="utf-8") as config_file:
    config = json.load(config_file)

TOKEN = config["token"]
Db_host = config["databaseHOST"]
DB_user = config["DBuser"]
DB_pass = config["DBpassword"]
DB_name = config["DBname"]

# MySQL connection function
def create_connection():
    try:
        connection = mysql.connector.connect(
            host=Db_host,
            user=DB_user,
            password=DB_pass,
            database=DB_name
        )
        if connection.is_connected():
            print("Connected to MySQL Database")
        return connection
    except Error as e:
        print(f"Error: '{e}'")
        return None

def setup_database():
    try:
        connection = mysql.connector.connect(
            host=Db_host,
            user=DB_user,
            password=DB_pass
        )
        if connection.is_connected():
            cursor = connection.cursor()
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS {DB_name}")
            cursor.execute(f"USE {DB_name}")

            create_table_query = """
            CREATE TABLE IF NOT EXISTS bans (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id BIGINT NOT NULL,
                banned_by BIGINT NOT NULL,
                reason TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS kicks (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id BIGINT NOT NULL,
                kicked_by BIGINT NOT NULL,
                reason TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS warnings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id BIGINT NOT NULL,
                warned_by BIGINT NOT NULL,
                reason TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS mutes (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id BIGINT NOT NULL,
                muted_by BIGINT NOT NULL,
                reason TEXT,
                end_time TIMESTAMP,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            """
            cursor.execute(create_table_query)
            print("Database and tables setup successfully.")
            cursor.close()
            connection.close()
    except Error as e:
        print(f"Error: '{e}'")

# Setup database and table
setup_database()

# Create a bot instance with all intents enabled
intents = discord.Intents.all()
bot = commands.Bot(intents=intents, command_prefix="!")

# Connect to the MySQL database
connection = create_connection()

@bot.event
async def on_ready():
    print("yo")
    print(f'We have logged in as {bot.user}')
    await bot.change_presence(activity=discord.Game(name="Liqver"))

# Error handler for command usage errors
@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.send(f"Missing arguments. Usage: `!{ctx.command.name} <member> [reason]`")
    elif isinstance(error, commands.CommandNotFound):
        await ctx.send("Command not found. Use `!help` to see all commands.")
    elif isinstance(error, commands.MissingPermissions):
        await ctx.send("You don't have permission to use this command.")
    else:
        await ctx.send(f"An error occurred: {str(error)}")

# Warn Command
@bot.command()
@commands.has_permissions(manage_messages=True)
async def warn(ctx, member: discord.Member, *, reason=None):
    if reason is None:
        reason = "No reason provided"
    try:
        await ctx.send(f'{member.mention} has been warned for: {reason}')

        # Save warning information to the database
        if connection is not None and connection.is_connected():
            cursor = connection.cursor()
            query = "INSERT INTO warnings (user_id, warned_by, reason) VALUES (%s, %s, %s)"
            values = (member.id, ctx.author.id, reason)
            cursor.execute(query, values)
            connection.commit()
            cursor.close()
            print(f"Warning information for {member} saved to database")

    except Error as e:
        print(f"Error: '{e}'")

# Mute Command
@bot.command()
@commands.has_permissions(manage_roles=True)
async def mute(ctx, member: discord.Member, duration: int, unit: str, *, reason=None):
    if reason is None:
        reason = "No reason provided"

    try:
        # Define the mute duration
        if unit == "s":
            delta = timedelta(seconds=duration)
        elif unit == "m":
            delta = timedelta(minutes=duration)
        elif unit == "h":
            delta = timedelta(hours=duration)
        elif unit == "d":
            delta = timedelta(days=duration)
        else:
            await ctx.send("Invalid time unit! Use `s`, `m`, `h`, or `d`.")
            return

        end_time = datetime.now() + delta

        # Find or create a mute role
        mute_role = discord.utils.get(ctx.guild.roles, name="Muted")
        if mute_role is None:
            mute_role = await ctx.guild.create_role(name="Muted")
            for channel in ctx.guild.channels:
                await channel.set_permissions(mute_role, speak=False, send_messages=False, read_message_history=True, read_messages=False)

        await member.add_roles(mute_role, reason=reason)
        await ctx.send(f'{member.mention} has been muted for {duration}{unit} for: {reason}')

        # Save mute information to the database
        if connection is not None and connection.is_connected():
            cursor = connection.cursor()
            query = "INSERT INTO mutes (user_id, muted_by, reason, end_time) VALUES (%s, %s, %s, %s)"
            values = (member.id, ctx.author.id, reason, end_time)
            cursor.execute(query, values)
            connection.commit()
            cursor.close()
            print(f"Mute information for {member} saved to database")

    except Error as e:
        print(f"Error: '{e}'")

# Unmute Command
@bot.command()
@commands.has_permissions(manage_roles=True)
async def unmute(ctx, member: discord.Member):
    try:
        # Find the mute role
        mute_role = discord.utils.get(ctx.guild.roles, name="Muted")
        if mute_role in member.roles:
            await member.remove_roles(mute_role)
            await ctx.send(f'{member.mention} has been unmuted.')

            # Optionally, update the database to mark the mute as ended
            if connection is not None and connection.is_connected():
                cursor = connection.cursor()
                query = "UPDATE mutes SET end_time = NOW() WHERE user_id = %s AND end_time > NOW()"
                values = (member.id,)
                cursor.execute(query, values)
                connection.commit()
                cursor.close()
                print(f"Unmute information for {member} saved to database")

    except Error as e:
        print(f"Error: '{e}'")

# Kick Command
@bot.command()
@commands.has_permissions(kick_members=True)
async def kick(ctx, member: discord.Member, *, reason=None):
    if reason is None:
        reason = "No reason provided"
    try:
        await member.kick(reason=reason)
        await ctx.send(f'{member.mention} has been kicked for: {reason}')

        # Save kick information to the database
        if connection is not None and connection.is_connected():
            cursor = connection.cursor()
            query = "INSERT INTO kicks (user_id, kicked_by, reason) VALUES (%s, %s, %s)"
            values = (member.id, ctx.author.id, reason)
            cursor.execute(query, values)
            connection.commit()
            cursor.close()
            print(f"Kick information for {member} saved to database")

    except discord.errors.Forbidden:
        await ctx.send("I don't have permission to kick this user.")
    except Error as e:
        print(f"Error: '{e}'")

# Ban Command
@bot.command()
@commands.has_permissions(ban_members=True)
async def ban(ctx, member: discord.Member, *, reason=None):
    if reason is None:
        reason = "No reason provided"

    try:
        # Ban the user from the server
        await member.ban(reason=reason)
        await ctx.send(f'{member.mention} has been banned for: {reason}')

        # Save ban information to the database
        if connection is not None and connection.is_connected():
            cursor = connection.cursor()
            query = "INSERT INTO bans (user_id, banned_by, reason) VALUES (%s, %s, %s)"
            values = (member.id, ctx.author.id, reason)
            cursor.execute(query, values)
            connection.commit()
            cursor.close()
            print(f"Ban information for {member} saved to database")

    except discord.errors.Forbidden:
        await ctx.send("I don't have permission to ban this user.")
    except Error as e:
        print(f"Error: '{e}'")

@bot.event
async def on_disconnect():
    if connection is not None and connection.is_connected():
        connection.close()
        print("MySQL connection is closed")

# Run the bot with the provided token
bot.run(TOKEN)
