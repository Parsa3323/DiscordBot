import discord
from discord.ext import commands
import json
import mysql.connector
from mysql.connector import Error
import os
import requests
import shutil
from datetime import datetime, timedelta
import zipfile

# Load configuration from the JSON file
with open("config.json", mode="r", encoding="utf-8") as config_file:
    config = json.load(config_file)

TOKEN = config["token"]
Status = config["BotStatus"]
Db_host = config["databaseHOST"]
DB_user = config["DBuser"]
DB_pass = config["DBpassword"]
DB_name = config["DBname"]

VERSION_URL = 'https://parsa3323.github.io/DiscordBot/Version.txt'  # URL to the version file
UPDATE_URL = 'http://parsa3323.github.io/DiscordBot/DiscordBot2.zip'  # URL to the update package
VERSION_FILE = 'Version.txt'  # Local version file

# Check for updates
def check_for_update():
    def get_latest_version():
        try:
            response = requests.get(VERSION_URL)
            response.raise_for_status()
            latest_version = response.text.strip()
            return latest_version
        except requests.RequestException as e:
            print(f"Error fetching version info: {e}")
            return None

    def get_current_version():
        if os.path.exists(VERSION_FILE):
            with open(VERSION_FILE, 'r') as file:
                return file.read().strip()
        return None

    def download_update():
        try:
            response = requests.get(UPDATE_URL, stream=True)
            response.raise_for_status()
            with open('update.zip', 'wb') as file:
                shutil.copyfileobj(response.raw, file)
            print("Update downloaded successfully.")
        except requests.RequestException as e:
            print(f"Error downloading update: {e}")

    def replace_files():
        try:
            with zipfile.ZipFile('update.zip', 'r') as zip_ref:
                zip_ref.extractall('.')  # Extract to the current directory
            print("Files replaced successfully.")
        except Exception as e:
            print(f"Error replacing files: {e}")

    latest_version = get_latest_version()
    current_version = get_current_version()

    if latest_version and (current_version is None or latest_version > current_version):
        print(f"New version available: {latest_version}")
        download_update()
        replace_files()
        # Update the local version file
        with open(VERSION_FILE, 'w') as file:
            file.write(latest_version)
        # After updating, restart the bot
        print("Update applied, restarting the bot...")
        os.execv(__file__, ['python'] + sys.argv)
    else:
        print("No updates available.")

# Run the update check and replace process
check_for_update()

# MySQL connection function
def create_connection():
    try:
        connection = mysql.connector.connect(
            host=Db_host,
            user=DB_user,
            password=DB_pass,
            database=DB_name
        )
        if connection.is_connected():
            print("Connected to MySQL Database")
        return connection
    except Error as e:
        print(f"Error: '{e}'")
        return None

def setup_database():
    try:
        connection = mysql.connector.connect(
            host=Db_host,
            user=DB_user,
            password=DB_pass
        )
        if connection.is_connected():
            cursor = connection.cursor()
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS {DB_name}")
            cursor.execute(f"USE {DB_name}")

            create_table_query = """
            CREATE TABLE IF NOT EXISTS bans (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id BIGINT NOT NULL,
                banned_by BIGINT NOT NULL,
                reason TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS kicks (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id BIGINT NOT NULL,
                kicked_by BIGINT NOT NULL,
                reason TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS warnings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id BIGINT NOT NULL,
                warned_by BIGINT NOT NULL,
                reason TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS mutes (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id BIGINT NOT NULL,
                muted_by BIGINT NOT NULL,
                reason TEXT,
                end_time TIMESTAMP,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            """
            cursor.execute(create_table_query, multi=True)
            print("Database and tables setup successfully.")
            cursor.close()
            connection.close()
    except Error as e:
        print(f"Error: '{e}'")

# Setup database and table
setup_database()

# Create a bot instance with all intents enabled
intents = discord.Intents.all()
bot = commands.Bot(intents=intents, command_prefix="!")

# Connect to the MySQL database
connection = create_connection()

@bot.event
async def on_ready():
    print(f'We have logged in as {bot.user}')
    await bot.change_presence(activity=discord.Game(name=Status))

@bot.command()
@commands.has_permissions(kick_members=True)
async def kick(ctx, member: discord.Member, *, reason=None):
    if reason is None:
        reason = "No reason provided"
    try:
        await member.kick(reason=reason)
        await ctx.send(f'{member.mention} has been kicked for: {reason}')

        if connection is not None and connection.is_connected():
            cursor = connection.cursor()
            query = "INSERT INTO kicks (user_id, kicked_by, reason) VALUES (%s, %s, %s)"
            values = (member.id, ctx.author.id, reason)
            cursor.execute(query, values)
            connection.commit()
            cursor.close()
            print(f"Kicking information for {member} saved to database")

    except discord.errors.Forbidden:
        await ctx.send("I don't have permission to kick this user.")
    except Error as e:
        print(f"Error: '{e}'")

@bot.command()
@commands.has_permissions(ban_members=True)
async def ban(ctx, member: discord.Member, *, reason=None):
    if reason is None:
        reason = "No reason provided"
    try:
        await member.ban(reason=reason)
        await ctx.send(f'{member.mention} has been banned for: {reason}')

        if connection is not None and connection.is_connected():
            cursor = connection.cursor()
            query = "INSERT INTO bans (user_id, banned_by, reason) VALUES (%s, %s, %s)"
            values = (member.id, ctx.author.id, reason)
            cursor.execute(query, values)
            connection.commit()
            cursor.close()
            print(f"Ban information for {member} saved to database")

    except discord.errors.Forbidden:
        await ctx.send("I don't have permission to ban this user.")
    except Error as e:
        print(f"Error: '{e}'")

@bot.command()
@commands.has_permissions(manage_messages=True)
async def warn(ctx, member: discord.Member, *, reason=None):
    if reason is None:
        reason = "No reason provided"
    try:
        if connection is not None and connection.is_connected():
            cursor = connection.cursor()
            query = "INSERT INTO warnings (user_id, warned_by, reason) VALUES (%s, %s, %s)"
            values = (member.id, ctx.author.id, reason)
            cursor.execute(query, values)
            connection.commit()
            cursor.close()
            print(f"Warning information for {member} saved to database")
        await ctx.send(f'{member.mention} has been warned for: {reason}')
    except Error as e:
        print(f"Error: '{e}'")

@bot.command()
@commands.has_permissions(manage_roles=True)
async def mute(ctx, member: discord.Member, duration: int, *, reason=None):
    if reason is None:
        reason = "No reason provided"
    try:
        role = discord.utils.get(ctx.guild.roles, name='Muted')
        if role is None:
            role = await ctx.guild.create_role(name='Muted')
            for channel in ctx.guild.channels:
                await channel.set_permissions(role, send_messages=False, speak=False)
        await member.add_roles(role)
        end_time = datetime.utcnow() + timedelta(minutes=duration)
        if connection is not None and connection.is_connected():
            cursor = connection.cursor()
            query = "INSERT INTO mutes (user_id, muted_by, reason, end_time) VALUES (%s, %s, %s, %s)"
            values = (member.id, ctx.author.id, reason, end_time)
            cursor.execute(query, values)
            connection.commit()
            cursor.close()
            print(f"Mute information for {member} saved to database")
        await ctx.send(f'{member.mention} has been muted for {duration} minutes for: {reason}')
    except Error as e:
        print(f"Error: '{e}'")

@bot.command()
@commands.has_permissions(manage_roles=True)
async def unmute(ctx, member: discord.Member):
    try:
        role = discord.utils.get(ctx.guild.roles, name='Muted')
        if role is not None:
            await member.remove_roles(role)
            if connection is not None and connection.is_connected():
                cursor = connection.cursor()
                query = "DELETE FROM mutes WHERE user_id = %s"
                values = (member.id,)
                cursor.execute(query, values)
                connection.commit()
                cursor.close()
                print(f"Unmute information for {member} saved to database")
            await ctx.send(f'{member.mention} has been unmuted.')
        else:
            await ctx.send('No "Muted" role found.')
    except Error as e:
        print(f"Error: '{e}'")

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.send(f"Missing arguments. Usage: `!{ctx.command.name} <member> [reason]`")
    elif isinstance(error, commands.CommandNotFound):
        await ctx.send("Command not found. Use `!help` to see all commands.")
    elif isinstance(error, commands.MissingPermissions):
        await ctx.send("You don't have permission to use this command.")
    else:
        await ctx.send(f"An error occurred: {str(error)}")

@bot.event
async def on_disconnect():
    if connection is not None and connection.is_connected():
        connection.close()
        print("MySQL connection is closed")

# Run the bot with the provided token
bot.run(TOKEN)
