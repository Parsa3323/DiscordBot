CREATE DATABASE discord_bot;
USE discord_bot;

CREATE TABLE bans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    banned_by BIGINT NOT NULL,
    reason TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
