import secrets
import json

def generate_license_key():
    return secrets.token_hex(16)  # Generates a unique 32-character key

def save_license_key(key, buyer_id):
    # This function should save the key and buyer_id to a secure database
    with open('licenses.json', 'a') as f:
        json.dump({"key": key, "buyer_id": buyer_id}, f)
        f.write('\n')

# Example usage
license_key = generate_license_key()
save_license_key(license_key, 'buyer123')
print(f"Generated license key: {license_key}")
