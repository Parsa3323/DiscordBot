from cryptography.fernet import Fernet
import json

# Generate a new key
def generate_key():
    key = Fernet.generate_key()
    with open('secret.key', 'wb') as key_file:
        key_file.write(key)

# Encrypt license data
def create_license(data):
    with open('secret.key', 'rb') as key_file:
        key = key_file.read()
    f = Fernet(key)
    encrypted_data = f.encrypt(data.encode())
    with open('license.key', 'wb') as license_file:
        license_file.write(encrypted_data)

# Example usage
generate_key()
create_license("your_license_data")
