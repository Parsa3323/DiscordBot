import pyAesCrypt

def encrypt_file(file_path, password):
    buffer_size = 64 * 1024
    encrypted_file_path = file_path + ".aes"
    pyAesCrypt.encryptFile(file_path, encrypted_file_path, password, buffer_size)
    print(f"Encrypted file saved as {encrypted_file_path}")

if __name__ == "__main__":
    file_path = "DiscordBot2.py"  # Replace with the name of the Python file you want to encrypt
    password = "ParsaNavazi"  # Use a strong, secure password
    encrypt_file(file_path, password)
