                                                            #▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
                                                            #██░▄▄░█░▄▄▀█░▄▄▀█░▄▄█░▄▄▀███▄▄░▄▄██▄██▀▄▀█░█▀█░▄▄█▄░▄█░▄▄
                                                            #██░▀▀░█░▀▀░█░▀▀▄█▄▄▀█░▀▀░█████░████░▄█░█▀█░▄▀█░▄▄██░██▄▄▀
                                                            #██░████▄██▄█▄█▄▄█▄▄▄█▄██▄█████░███▄▄▄██▄██▄█▄█▄▄▄██▄██▄▄▄
                                                            #▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀





                                                                                                         
                                                                                                                                                    
                                            #        CCCCCCCCCCCCC                                      ffffffffffffffff    iiii                      
                                            #     CCC::::::::::::C                                     f::::::::::::::::f  i::::i                     
                                            #   CC:::::::::::::::C                                    f::::::::::::::::::f  iiii                      
                                            #  C:::::CCCCCCCC::::C                                    f::::::fffffff:::::f                            
                                            # C:::::C       CCCCCC   ooooooooooo   nnnn  nnnnnnnn     f:::::f       ffffffiiiiiii    ggggggggg   ggggg
                                            #C:::::C               oo:::::::::::oo n:::nn::::::::nn   f:::::f             i:::::i   g:::::::::ggg::::g
                                            #C:::::C              o:::::::::::::::on::::::::::::::nn f:::::::ffffff        i::::i  g:::::::::::::::::g
                                            #C:::::C              o:::::ooooo:::::onn:::::::::::::::nf::::::::::::f        i::::i g::::::ggggg::::::gg
                                            #C:::::C              o::::o     o::::o  n:::::nnnn:::::nf::::::::::::f        i::::i g:::::g     g:::::g 
                                            #C:::::C              o::::o     o::::o  n::::n    n::::nf:::::::ffffff        i::::i g:::::g     g:::::g 
                                            #C:::::C              o::::o     o::::o  n::::n    n::::n f:::::f              i::::i g:::::g     g:::::g 
                                            # C:::::C       CCCCCCo::::o     o::::o  n::::n    n::::n f:::::f              i::::i g::::::g    g:::::g 
                                            #  C:::::CCCCCCCC::::Co:::::ooooo:::::o  n::::n    n::::nf:::::::f            i::::::ig:::::::ggggg:::::g 
                                            #   CC:::::::::::::::Co:::::::::::::::o  n::::n    n::::nf:::::::f            i::::::i g::::::::::::::::g 
                                            #     CCC::::::::::::C oo:::::::::::oo   n::::n    n::::nf:::::::f            i::::::i  gg::::::::::::::g 
                                            #        CCCCCCCCCCCCC   ooooooooooo     nnnnnn    nnnnnnfffffffff            iiiiiiii    gggggggg::::::g 
                                            #                                                                                                 g:::::g 
                                            #                                                                                     gggggg      g:::::g 
                                            #                                                                                     g:::::gg   gg:::::g 
                                            #                                                                                      g::::::ggg:::::::g 
                                            #                                                                                       gg:::::::::::::g  
                                            #                                                                                         ggg::::::ggg    
                                            #                                                                                            gggggg       

#Thanks for buying ParsaTickets u can Create tickets with it easly
# -----------------------------------reqs-------------------------
# Run Req.bat or run req.txt file
#-----------------------------------config-----------------------:


TOKEN = "MTI3MDMzMTc3MTQzMDM3MTM4OA.GY3AW1.kGUSuDhNJ4-D8fkPMkI7OUu6XVYJekgf5qOOsg" #enter your discord bot token
BotTicketMessage = "Welcome to this server Click 🎫 to open a ticket" #Enter the message u want to send to ticket channel
BotTicketMessageTitle = "Ticket"
BotStatus = "Ticket bot By Parsa" #Playing Your status
EmbedFooter = "Made By Parsa(remove)"
EmbedColor = "" #Enter your fav color for discord embeds
BotTicketMessageOpen = "Welcome to ticket staffs will help u soon.. click ❌ to close" #Enter your message for opened tickets
#emojis
CloseEmoji = "❌"
openemoji = "🎫"

